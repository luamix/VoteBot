# voteBot
VoteBot is a bot to automatically vote on https://poll.fm/.

It's writed in Javascript and JQuery with Puppeteer.


# How to use

1. Downoad and install Node.js.

2. Download and install Puppeteer.

3. Open voteBot.js with Notepad or your favourite code editor.

4. Change the pollURL value with your poll URL.

5. Open your poll page, copy your answer ID and paste it in the answerId value.

6. Save it and close the file.

7. Launch runVoteBot.bat, if you have Windows, and watch voteBot to vote for you infinite times with a pause after 23 votes.

8. Alternatively, you can launch voteBot.js to vote one time.
